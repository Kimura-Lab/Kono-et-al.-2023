Modified R commander for EZR ver. 1.61a-0 (Windows) 
===================================================

This content provides several modifications by Yohei Kono to the EZR
ver. 1.61 programmed by Yoshinobu Kanda, which is a customized plugin
of the R Commander ver. 2.8-0 developed by John Fox.
These patches enable user-friendly manipulation of Games-Howell tests
on Aoki_all.R, Hatano_socialStatisticsBasic.R and rstatix package, and
other useful statistic analyses.

'.Rporfile' is a setup file for CRAN mirror, internet proxy and others.
You can fit it to your environment and place it in
C:\Users\username\Documents to use it.


Installation
============

Change the extensions of the 'EZR.R' and 'Rcmdr-menus.txt' files in
\EZR\library\Rcmdr\etc\ to .old respectively and replace the unzipped
'EZR.R' and 'Rcmdr-menus.txt' files instead.


Translation to Japanese
=======================

To translate the added English menu into Japanese, change the extensions
of 'R-Rcmdr.po' and 'R-Rcmdr.mo' in EZR\library\Rcmdr\po\ja\LC_MESSAGES\
to 'R-Rcmdr.po.old' and 'R-Rcmdr.mo.old', and replace the unzipped
'R-Rcmdr.po' and 'R-Rcmdr.mo' instead.


Usage
=====

At first, you must install 'rstatix' package on R Console.

The Games-Howell test using Aoki_all.R is added into 'One-way ANOVA' in
'Continuous variables' menu as a option of 'Welch test'.

'Multiple comparison test (Hatano)...' using Hatano_socialStatisticsBasic.R
is added into 'Continuous variables' menu.

'Games-Howell test (rstatix)...' using rstatix package is added into
'Continuous variables' menu.

Added the 'Levene's Test' from the original Rcmdr menu into 
'Nonparametric tests' menu, making it easier to use the Brown-Forsythe
test (median version of Levene's Test).

Added the 'Fligner-Killeen test...' into 'Nonparametric tests' menu.


Tips
====
When you perform the Games-Howell test on rstatix package, if there are
10 more results like below, 
"… with 18 more rows"
"Use 'print(n = ...)' to see more rows"
, then write 'print (res, n = 28)' in R script window and run it.


Customization
=============

Many R defaults can be set in the file R_HOME\etc\Rprofile or a user's
file .Rprofile, and a copy with a user's settings can be put in her HOME
directory or in the working directory.  (The exact sequence is to search
the directory pointed to by the first found of the environment variables
R_USER then HOME, then the Windows "personal" directory (typically
'C:\Users\username\Documents' on recent versions of Windows) then 
{HOMEDRIVE}{HOMEPATH} then the working directory, finally R_HOME\etc.
